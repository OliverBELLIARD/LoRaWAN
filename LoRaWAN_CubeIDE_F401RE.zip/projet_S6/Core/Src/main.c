/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <stdlib.h>
#include <string.h>

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define UART_TX_BUFFER_SIZE 32
#define MAX_MSG_SIZE 4000 // Max characters in a message
#define E5_WAIT 400 // Max delay between 2 commands

#define AT_SET_ZONE "AT+DR=EU868\r\n" // set the zone, can be U915...
#define AT_SET_TIMEOUT "AT+UART=TIMEOUT, 0\r\n"
#define AT_GET_INFO "AT+INFO\r\n"

#define AT_RESET "AT+RESET\r\n"
#define AT_DEBUG_ON "AT+LOG=DEBUG\r\n"
#define AT_TEST_MODE "AT+MODE=TEST\r\n"
#define AT_TEST_TX1 "AT+TEST=TXLRPKT, \""
#define AT_TEST_TX2 "AT+TEST=TXLRSTR, \""
#define AT_TEST_RX "AT+TEST=RXLRPKT\r\n"

#define ID 01
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
const char boot[] = "Booting...\r\n";
const char hello[] = "Hello World!\r\n";
char uart1_rx_buffer[1]=" ";
char uart2_rx_buffer[1]=" ";
char uart_tx_buffer[UART_TX_BUFFER_SIZE]={};
int it_uart1 = 0;
int it_uart2 = 0;
int mode = 0x00;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART1_UART_Init(void);
/* USER CODE BEGIN PFP */
void lora_at_init(void);
void test_at_tx(char msg[]);
void test_at_rx(void);

void send_message(char msg[]);
void receive_message(char msg[]);

int hex_to_int(char c);
int hex_to_ascii(char c, char d);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
	/* USER CODE BEGIN 1 */

	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_USART2_UART_Init();
	MX_USART1_UART_Init();
	/* USER CODE BEGIN 2 */
	//HAL_UART_Transmit(&huart2, boot, sizeof(boot), HAL_MAX_DELAY);

	HAL_UART_Receive_IT(&huart2, uart1_rx_buffer, 1);
	HAL_UART_Receive_IT(&huart1, uart2_rx_buffer, 1);

	// Reset AT parameters
	lora_at_init();
	test_at_rx();

	/* USER CODE END 2 */

	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	while (1)
	{
		//HAL_Delay(E5_WAIT);
		/* test code to blink the led every 1s */
		//HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin); // toggles led pin
		//send_message("Hello World!");
		receive_message(uart1_rx_buffer);

		// IF PUSH KEY form uart2
		if(it_uart2){
			// Echo
			uart_tx_buffer[0] = uart2_rx_buffer[0];
			if(uart2_rx_buffer[0]==13){
			  HAL_UART_Transmit(&huart2, "\r\n", 2, HAL_MAX_DELAY);
			}
			else{
			  HAL_UART_Transmit(&huart2, uart_tx_buffer, 1, HAL_MAX_DELAY);
			}
			HAL_UART_Transmit(&huart1, uart_tx_buffer, 1, HAL_MAX_DELAY);
			it_uart2 = 0;
		}

		if(it_uart1){
			// Echo
			uart_tx_buffer[0] = uart1_rx_buffer[0];
			if(uart1_rx_buffer[0]==13){
			  HAL_UART_Transmit(&huart2, "\r\n", 2, HAL_MAX_DELAY);
			}
			else{
			  HAL_UART_Transmit(&huart2, uart_tx_buffer, 1, HAL_MAX_DELAY);
			}
			it_uart1 = 0;
	  }

	/* USER CODE END WHILE */

	/* USER CODE BEGIN 3 */
	}
	/* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  //huart1.Init.BaudRate = 115200;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;

  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){
	if(huart==&huart1){
		it_uart1 = 1;
		HAL_UART_Receive_IT(&huart1, uart1_rx_buffer, 1);
	}
	if(huart==&huart2){
		it_uart2 = 1;
		HAL_UART_Receive_IT(&huart2, uart2_rx_buffer, 1);
	}
}

void lora_at_init(void) {

	// Reset LoRa-E5
	HAL_Delay(E5_WAIT);
	HAL_UART_Transmit(&huart1, AT_RESET, sizeof(AT_RESET), HAL_MAX_DELAY);
	HAL_UART_Transmit(&huart2, AT_RESET, sizeof(AT_RESET), HAL_MAX_DELAY);

	// Enable AT debug mode
	HAL_Delay(E5_WAIT);
	HAL_UART_Transmit(&huart1, AT_DEBUG_ON, sizeof(AT_DEBUG_ON), HAL_MAX_DELAY);
	HAL_UART_Transmit(&huart2, AT_DEBUG_ON, sizeof(AT_DEBUG_ON), HAL_MAX_DELAY);

	// Set timeout to 0
	HAL_Delay(E5_WAIT);
	HAL_UART_Transmit(&huart1, AT_SET_TIMEOUT, sizeof(AT_SET_TIMEOUT), HAL_MAX_DELAY);
	HAL_UART_Transmit(&huart2, AT_SET_TIMEOUT, sizeof(AT_SET_TIMEOUT), HAL_MAX_DELAY);

	// Get info from LoRa-E5
	HAL_Delay(E5_WAIT);
	HAL_UART_Transmit(&huart1, AT_GET_INFO, sizeof(AT_GET_INFO), HAL_MAX_DELAY);
	HAL_UART_Transmit(&huart2, AT_GET_INFO, sizeof(AT_GET_INFO), HAL_MAX_DELAY);

	// Enter test mode (LoRa communication only)
	HAL_Delay(E5_WAIT);
	HAL_UART_Transmit(&huart1, AT_TEST_MODE, sizeof(AT_TEST_MODE), HAL_MAX_DELAY);
	HAL_UART_Transmit(&huart2, AT_TEST_MODE, sizeof(AT_TEST_MODE), HAL_MAX_DELAY);
}

/*******************************************************************
 * DO NOT TOUCH! ;)
 * @param char[] message to send
 */
void test_at_tx(char msg[]) {

	char atCommand[MAX_MSG_SIZE] = AT_TEST_TX2;
	char data[MAX_MSG_SIZE-sizeof(AT_TEST_TX2)-3] = {};
	int i = 0;

	// Get message from memory
	while(msg[i] != '\0') {
		data[i] = msg[i];
		i++;
	}

	// Building AT command to send message
	strcat(atCommand, data);
	strcat(atCommand, "\"\r\n");

	// Send message
	HAL_UART_Transmit(&huart2, atCommand, sizeof(atCommand), HAL_MAX_DELAY);
	HAL_UART_Transmit(&huart1, atCommand, sizeof(atCommand), HAL_MAX_DELAY);
}

void send_message(char msg[]) {

	char msg_complet[MAX_MSG_SIZE-100]="#";
	char data[MAX_MSG_SIZE-105];
	char id[3] = {(ID-ID%10)+48, 48+ID%10};
	int i = 0;
	int j = 0;

	// Get message from memory
	while(msg[i] != '\0') {
		data[i] = msg[i];
		i++;
	}
	for (j=i; j<MAX_MSG_SIZE-105; j++) {
		data[j]=0;
	}

	strcat(msg_complet, id);
	strcat(msg_complet, "$");
	// temp
	strcat(msg_complet, "0");
	strcat(msg_complet, "$");
	strcat(msg_complet, data);
	strcat(msg_complet, "?");

	test_at_tx(msg_complet);
}

/*******************************************
 * TODO: explain to each group that the entry variable should be a char
 *
 */
void receive_message(char msg[]) {

	char data[MAX_MSG_SIZE];
	int i = 0;
	int j = 0;

	/*
	// Get message from memory
	while(msg[i] != '\0') {
		data[i] = msg[i];
		i++;
	}
	i = 0;

	// If data = '#'
	if (data[0]=='2' && data[1]=='3') {
		// If data = ID
		if ( (data[2]==(ID-ID%10+48)) && (data[3]==(ID%10+48)) ) {
			i=69;
		}
	}

	if (i) {
		// If data = '$'
		if (data[4]='2' && data[5]=='4') {
			// If data = any int between 0 & 9 (who knows...)
			mode = data[7]-48;
		}

		// If data = '$'
		if (data[8]='2' && data[9]=='4') {

			// Decode all DATA
			while(data[i] != '\0') {
				final_data[i-i/2] = hex_to_ascii(data[i], data[i+1]);
				i+=2;
			}
		}
	}
	*/
	while(msg[i] != '\0') {
		data[j] = hex_to_ascii(msg[i], msg[i+1]);
		i+=2;
		j++;
	}

	for (i=j; i<MAX_MSG_SIZE; i++) {
		data[i]=0;
	}

	if (data[0]=='#' // Beginning of  protocol thread
		&& ((data[1]-48)*16 + data[2]-48)==ID	// ID verification
		&& data[3]=='$') // Continuity of data verification
	{
		mode = data[4] - 48; // Interprete mode

		if (data[5]='$') {
			i = 6;

			while(data[i] != '\0') {
				/* DEBUT DE LA ZONE OU VOUS DEVEZ METTRE VOTRE CODE */

				/* FIN DE LA ZONE OU VOUS DEVEZ METTRE VOTRE CODE */
				i++;
			}
		}
	}
	else
	{
		// The received data is not for this device nor from protocol
	}

	HAL_UART_Transmit(&huart2, data, sizeof(data), HAL_MAX_DELAY);
}

void test_at_rx(void) {

	HAL_Delay(E5_WAIT);
	// Enter receive mode
	HAL_UART_Transmit(&huart1, AT_TEST_RX, sizeof(AT_TEST_RX), HAL_MAX_DELAY);
	HAL_UART_Transmit(&huart2, AT_TEST_RX, sizeof(AT_TEST_RX), HAL_MAX_DELAY);
}

int hex_to_int(char c) {

        int first = c / 16 - 3;
        int second = c % 16;
        int result = first*10 + second;

        if(result > 9) result--;
        return result;
}

int hex_to_ascii(char c, char d) {

        int high = hex_to_int(c) * 16;
        int low = hex_to_int(d);

        return high+low;
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
